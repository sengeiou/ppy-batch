package com.puppyou.batch.service;

public interface MatchingService {
	
	public void beforeMatchingEndJob();
	
	public void resetMatchingJob();

}
