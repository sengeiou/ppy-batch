package com.puppyou.batch.service;

public interface PuppyService {
	
	public void puppyPlusAge();

}
