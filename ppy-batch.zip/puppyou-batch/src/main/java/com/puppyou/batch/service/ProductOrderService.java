package com.puppyou.batch.service;

public interface ProductOrderService {
	
	public void complateProductStatus();

}
