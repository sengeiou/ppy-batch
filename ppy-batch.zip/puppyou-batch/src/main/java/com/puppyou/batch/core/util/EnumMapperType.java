package com.puppyou.batch.core.util;

public interface EnumMapperType {
	String getCode();
	String getLabel();
}
