package com.puppyou.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PuppyouBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
